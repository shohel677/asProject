package mapObject;

public class gmDirectionObject {

}
