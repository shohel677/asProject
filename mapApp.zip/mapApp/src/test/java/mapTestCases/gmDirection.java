package mapTestCases;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import mapBase.base;

public class gmDirection extends base {
	@Test
	public void gmDirectionTest() throws MalformedURLException {

		AndroidDriver<AndroidElement> driver = capabilities();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByXPath("//android.widget.Button[@text=\"SKIP\"]").click();
		driver.findElementByXPath("//android.widget.TextView[@text=\"Search here\"]").click();
		driver.findElementByXPath("//android.widget.EditText[@text=\"Search here\"]").sendKeys("Gulshan");
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		driver.findElementByXPath("//android.widget.Button[@text=\"Directions\"]").click();
		driver.findElementByXPath("//android.widget.TextView[@text=\"Choose starting point\"]").click();
		driver.findElementById("com.google.android.apps.maps:id/search_omnibox_edit_text").sendKeys("Mirpur");
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		String distanceText = driver.findElementByXPath("//android.widget.TextView[2]").getText();  
		distanceText = distanceText.replaceAll("[-()+^]*", "");  
		System.out.println(distanceText);
		Assert.assertEquals("7.3 km", distanceText);
		
		
		
		
	}
}
