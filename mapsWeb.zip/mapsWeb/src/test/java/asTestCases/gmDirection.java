package asTestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import asBase.base;
import asObject.gmDirectionObj;

public class gmDirection extends base {
  @Test
  public void gmDirectionTest() {
	  gmDirectionObj gmDirect= new gmDirectionObj(driver);
	  gmDirect.entertoLocation().sendKeys("Rampura");
	  gmDirect.entertoLocation().sendKeys(Keys.ENTER);
	  gmDirect.directionButton().click();
	  Actions startLocation = new Actions(driver);
	  WebElement field = gmDirect.toLocation();
	  startLocation.click(field).sendKeys("Mirpur").sendKeys(Keys.ENTER).build().perform();
	  String distanceText = gmDirect.distanceTextGet().getText();
	  System.out.println(distanceText);
	  Assert.assertEquals("13.5 km", distanceText);
	  
  }
}
