package asObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class gmDirectionObj {
	
	WebDriver driver;

	public gmDirectionObj(WebDriver driver) {
		this.driver = driver;
	}
	By entertoLocation = By.name("q");
	public WebElement entertoLocation() {
		return driver.findElement(entertoLocation);
	}
	By directionButton = By.xpath("//*[@id=\"QA0Szd\"]/div/div/div[1]/div[2]/div/div[1]/div/div/div[4]/div[1]/button/span/img");
	public WebElement directionButton() {
		return driver.findElement(directionButton);
	}
	By toLocation = By.xpath("(//*[@class=\"sbib_b\"])[2]");
	public WebElement toLocation() {
		return driver.findElement(toLocation);
	}
	By distanceTextGet = By.xpath("//*[@id=\"section-directions-trip-0\"]/div[1]/div[1]/div[1]/div[2]/div");
	public WebElement distanceTextGet() {
		return driver.findElement(distanceTextGet);
	}
}
