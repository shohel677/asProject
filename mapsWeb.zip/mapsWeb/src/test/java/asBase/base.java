package asBase;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;

public class base {
	public WebDriver driver;
	public static String browser = "chrome";
  @BeforeSuite
  public WebDriver initializeDriver() {
	  if(browser.equals("chrome")) {
		  WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
	  }
	  else if(browser.equals("firefox")) {
		  WebDriverManager.firefoxdriver().setup();
		  driver = new FirefoxDriver();
		  
	  }
	  else if (browser.equals("edge")) {
		  WebDriverManager.edgedriver().setup();
		  driver = new EdgeDriver();
		  
	  }
	  driver.manage().window().maximize();
	  driver.get("https://www.google.com/maps/@23.7984941,90.3842619,15z?hl=en");
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	  return driver;
  }
  @BeforeTest
  public void initialize() {
	  driver = initializeDriver();
  }
  @AfterTest
  public void afterTest() throws InterruptedException {
	  Thread.sleep(3000);
  }
  @AfterSuite
  public void afterSuite() throws InterruptedException {
	  Thread.sleep(3000);
	  driver.close();
  }
}
